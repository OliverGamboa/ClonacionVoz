package com.example.clonacionvoz

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.*

class DetalleUsuarioActivity : AppCompatActivity() {

    private lateinit var listaHistorial: ListView
    private val db = FirebaseFirestore.getInstance()
    private val historial = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detalle_usuario)

        listaHistorial = findViewById(R.id.listaHistorial)
        val uidUsuario = intent.getStringExtra("uidUsuario")

        if (uidUsuario == null) {
            Toast.makeText(this, "Error: Usuario no especificado", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        db.collection("evaluaciones")
            .whereEqualTo("uid", uidUsuario)
            .get()
            .addOnSuccessListener { result ->
                if (result.isEmpty) {
                    historial.add("Este usuario no ha realizado ninguna evaluación.")
                } else {
                    val datosOrdenados = result.documents.sortedWith(compareBy({ it.getLong("leccion") ?: 0L }, { -(it.getTimestamp("fecha")?.seconds ?: 0) }))

                    for (doc in datosOrdenados) {
                        val leccion = doc.getLong("leccion")?.toInt() ?: -1
                        val puntaje = doc.getLong("puntaje")?.toInt() ?: 0
                        val total = doc.getLong("totalPreguntas")?.toInt() ?: 9
                        val timestamp = doc.getTimestamp("fecha")

                        val fecha = timestamp?.toDate()?.let {
                            val format = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
                            format.format(it)
                        } ?: "Fecha no disponible"

                        historial.add("📘 Lección $leccion\n📅 $fecha\n🟢 Puntaje: $puntaje/$total")
                    }
                }

                val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, historial)
                listaHistorial.adapter = adapter
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error al cargar historial", Toast.LENGTH_SHORT).show()
            }
    }
}
