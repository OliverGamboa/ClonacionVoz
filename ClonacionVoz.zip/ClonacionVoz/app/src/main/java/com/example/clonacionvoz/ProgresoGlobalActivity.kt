package com.example.clonacionvoz

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.google.firebase.firestore.FirebaseFirestore

class ProgresoGlobalActivity : AppCompatActivity() {

    private lateinit var barChart: BarChart
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_progreso_global)

        barChart = findViewById(R.id.barChartProgreso)

        db.collection("evaluaciones")
            .get()
            .addOnSuccessListener { result ->

                val puntajesPorLeccion = mutableMapOf<Int, MutableList<Int>>()

                for (doc in result) {
                    val leccion = doc.getLong("leccion")?.toInt() ?: continue
                    val puntaje = doc.getLong("puntaje")?.toInt() ?: 0

                    if (!puntajesPorLeccion.containsKey(leccion)) {
                        puntajesPorLeccion[leccion] = mutableListOf()
                    }
                    puntajesPorLeccion[leccion]?.add(puntaje)
                }

                val entries = mutableListOf<BarEntry>()
                val etiquetas = mutableListOf<String>()

                puntajesPorLeccion.toSortedMap().forEach { (leccion, lista) ->
                    val promedio = if (lista.isNotEmpty()) lista.average().toFloat() else 0f
                    entries.add(BarEntry(leccion.toFloat(), promedio))
                    etiquetas.add("Lec. $leccion")
                }

                val dataSet = BarDataSet(entries, "Promedio por Lección")
                val barData = BarData(dataSet)

                barChart.data = barData
                barChart.setFitBars(true)
                barChart.description.isEnabled = false
                barChart.axisRight.isEnabled = false
                barChart.axisLeft.axisMinimum = 0f
                barChart.axisLeft.axisMaximum = 9f

                val xAxis = barChart.xAxis
                xAxis.valueFormatter = IndexAxisValueFormatter(etiquetas)
                xAxis.position = XAxis.XAxisPosition.BOTTOM
                xAxis.granularity = 1f
                xAxis.setDrawGridLines(false)

                barChart.invalidate()
            }
    }
}
